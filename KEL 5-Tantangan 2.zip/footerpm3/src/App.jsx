import { useState } from 'react';
import React from 'react';
const Footer = () => (
  <footer className="bg-gray-800 text-white p-4 mt-8 rounded-t-lg text-center">
    <p className="text-sm">
      &copy; {new Date().getFullYear()} My React App. All rights reserved.
    </p>
  </footer>
);

// This is the main App component. It now only renders the Footer.
// You can add other components and content here as you build your application.
function App() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-100 font-sans text-gray-800">
      <main className="flex-grow flex flex-col items-center justify-center p-8">
        {/* This area is currently empty and ready for your content. */}
        <div className="text-center text-lg text-gray-500">
          This is where your main application content will go.
        </div>
      </main>
      <Footer />
    </div>
  );
}

export default App;
