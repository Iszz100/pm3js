import React from 'react';

// Komponen Footer sederhana dengan tahun otomatis
function Footer() {
  return (
    <footer className="bg-gray-800 text-white p-4 mt-8 rounded-t-lg text-center">
      <p className="text-sm">
        &copy; {new Date().getFullYear()} My React App. All rights reserved.
      </p>
    </footer>
  );
}

// Ekspor komponen agar bisa diimpor di file lain
export default Footer;
